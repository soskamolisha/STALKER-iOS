# STALKER Mobile — iOS starter (not a game port)

Target: iPhone 15 Pro Max, iOS 27, arm64.

This archive contains a **SwiftUI placeholder interface only**. It does not contain a runnable X-Ray engine, original S.T.A.L.K.E.R. game data, or an IPA. No claim of functional game compatibility is made.

## Verified APK inspection
- Source APK: `stalker-mobile-1.0.30.apk`
- 4,004 archive entries
- Android arm64 libraries: `libxrsoc.so`, `libxrcop.so`, `libSDL2.so`, `libopenal.so`, `libskinview.so`, `libc++_shared.so`
- These Android ELF `.so` libraries cannot be directly linked into an iOS app.

## Next engineering tasks
1. Obtain an appropriately licensed, buildable source tree of the X-Ray port and determine Shadow of Chernobyl support.
2. Port platform integration to iOS (graphics backend, filesystem, audio, input, lifecycle, permissions).
3. Replace placeholder SwiftUI controls with real engine input events and embed the engine view.
4. Add legally obtained original game assets (not included in APK).
5. Create an Xcode iOS app target, configure signing, compile on macOS/cloud macOS CI, and test on-device.

## How to use
Create a new iOS App project in Xcode (SwiftUI lifecycle), then replace the generated App source with `Sources/StalkerStarterApp.swift`. This is intentionally a minimal source starter, **not** an `.xcodeproj` and not a buildable IPA by itself.

Without a Mac, a properly configured remote macOS build service and Apple signing setup are required. iOS sideloading tools cannot convert Android binaries into iOS binaries.
